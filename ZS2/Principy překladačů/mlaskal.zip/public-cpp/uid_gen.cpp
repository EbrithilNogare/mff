/*

	uid_gen.cpp

	Unique ID generator

	Kuba, 2006

*/

#include "uid_gen.hpp"

namespace mlaskal {

	uid_all_type uid_all;

}

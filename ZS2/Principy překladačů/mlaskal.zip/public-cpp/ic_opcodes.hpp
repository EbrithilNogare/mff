#ifndef GUARD_MLASKAL_IC_OPCODES_HPP_
#define GUARD_MLASKAL_IC_OPCODES_HPP_

/*

	ic_opcodes.hpp

	IC opcodes

	Kuba, 2006

*/

#include "gen_icopcodes.hpp"

#endif
